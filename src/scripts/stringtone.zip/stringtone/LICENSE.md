# LICENSE TYPE: OFFENSIVE LIMERICK

```
There once was a Dev from East Mass.,
who wished to ensure his code could be passed.
Feeling most license types,
  weren't worth all the hype
Wrote his own as an iconoclast.

His peers thought him a narcissist,
to attempt to add his to the list.
But once fully conceived,
  'taw then they believed
(His intent was to get Legal pissed).

For he knew that he'd hit on the trick:
to the way to make the license stick:
"It should make PO's pallid,
  but be legally valid,
& be self-referential as shit."

So you found this library at last.
And it does more than you'd thought to ask.
Now your quandary at hand
  Is this author's demand,
This jurus-tic condition's attached.

This license is intended to be
A way to ensure that, for me,
Should it screw your site up
  I can not give a fuck;
I'm exempted from liability.

It's not that I don't care, I do!
Use it as source or to make revenue.
Keep this message intact
  (be the source changed or hacked),
& you can treat it like MPL 2.0.

You're thus granted, worldwide & free,
rights to use it for sale or I.P.
But save those rights above
  (If push comes to shove),
It's "as-is" (sans pledge/warranty).

Should trademark/copyright abuse
Come from your violating Fair Use
Since, along with the rest,
  There's no promise expressed,
's'not my beef (no matter how obtuse).

Code you've written on top remains yours,
So long as you/your devs have ensured
The bits that came from me,
  are available, free,
& this verbatim license endures.

Your rights to this license get tossed,
If this Open Source notice gets lost.
If someone else sues
  due to any abuse,
It's on you to pay my legal costs.

So why the rude license in verse?
It's the thought of some future Dev's mirth
I can't help but smile
  (however infantile)
at aggravating corporate stuffed shirts.

Plus years from now, 'cross time & space
After my consciousness's code's been erased
Some future Dev, far from here,
  will laugh as it appears,
From the bowels of their employers codebase

I can envision him as he says,
"Our license's no good, lest it stays.
I COULD spend a few sprints
  (though it'd be time poorly spent)
Recoding it (It could take days!)."

Mr. Manager, I hope that it's clear:
That you MUST see this notice appears.
To the Dev: hold your ground.
  In two decades I've found
wasting money's their primary fear.

Now I've no doubt that there will be some,
Who think such legal stanzas are dumb.
But those few folk (like me!),
  who give out this stuff, free
May well see where I'm coming from.

After all, it's a pretty safe bet:
Nerd cred's all the thanks that I'll get.
And telling my grandson (3)
  that his old grandpappi
Once played keyboard for the Internet.

Thus I hope in my code you've found worth.
And in these words equivalent mirth.
For we must stick together
  (Open Source dictates whether
the geek truly inherit the earth).

Really all I ask is credit due,
Without some jerk asserting it's new.
So before making the claim,
  It was done in your name,
Know I use Git/StackOverflow, too.
```

## Addendum
_
```
A codicil: added because
Folk've kept asking me if there was
A way they could stick
My license limerick
On their own code to give it some claws.

Well, of course (since this license you view
Is part of this code package too).
But just to clarify:
The same terms apply;
It's covered under its own purview.

Its terms must be followed, to wit:
This whole text must be shown (don't omit!).
Yes, including this part
(I did say at the start
It was self-referential as shit).

So it too may be used - and for free -
Just so long as you do credit me.
Made in twenty-twelve (circ.),
By @JJ/ZenAtWork
DBA Nerdy Deeds, LLC
```
_
